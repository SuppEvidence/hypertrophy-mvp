"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/auth/server";
import { ensureProfile } from "@/lib/auth/profile";
import { prisma } from "@/lib/db/prisma";
import { ensureProgramTemplates } from "@/lib/server/templates";
import { finishWorkoutSchema, sessionExerciseSchema, startWorkoutSchema, workoutSetSchema } from "@/lib/validations/workout";

async function requireUserId() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  await ensureProfile(user);
  return user.id;
}

function numberOrNull(value: FormDataEntryValue | null) {
  if (value === null || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function cleanText(value: FormDataEntryValue | null) {
  return String(value ?? "").trim();
}


function editableSessionStatusWhere() {
  const statuses: ("DRAFT" | "COMPLETED")[] = ["DRAFT", "COMPLETED"];
  return { in: statuses };
}

function revalidateWorkoutViews() {
  revalidatePath("/log");
  revalidatePath("/log/history");
  revalidatePath("/dashboard");
  revalidatePath("/performance");
}

function parseNullableNumberInput(value: unknown) {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function estimateE1rm(weight: number, reps: number) {
  return weight * (1 + reps / 30);
}

function roundToNearestHalf(value: number) {
  return Math.round(value * 2) / 2;
}

type WeightSuggestion = {
  suggestedWeight: number | null;
  targetReps: number | null;
  sourceE1rm: number | null;
  sourceSet: string | null;
};

async function buildWeightSuggestionsForSession(
  activeSession: Awaited<ReturnType<typeof getSessionForUser>>,
  userId: string,
): Promise<Record<string, WeightSuggestion>> {
  if (!activeSession) return {};

  const exerciseIds = Array.from(new Set(activeSession.exercises.map((item) => item.exerciseId)));
  if (exerciseIds.length === 0) return {};

  const completedSets = await prisma.workoutSet.findMany({
    where: {
      isCompleted: true,
      weight: { not: null },
      reps: { not: null },
      sessionExercise: {
        exerciseId: { in: exerciseIds },
        session: { userId, status: "COMPLETED", id: { not: activeSession.id } },
      },
    },
    include: {
      sessionExercise: {
        select: {
          exerciseId: true,
          session: { select: { performedAt: true } },
        },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  const bestByExercise = new Map<string, { e1rm: number; weight: number; reps: number }>();

  for (const set of completedSets) {
    const weight = Number(set.weight);
    const reps = set.reps;
    if (!Number.isFinite(weight) || !reps || reps <= 0) continue;

    const e1rm = estimateE1rm(weight, reps);
    const exerciseId = set.sessionExercise.exerciseId;
    const current = bestByExercise.get(exerciseId);
    if (!current || e1rm > current.e1rm) {
      bestByExercise.set(exerciseId, { e1rm, weight, reps });
    }
  }

  const suggestions: Record<string, WeightSuggestion> = {};

  for (const item of activeSession.exercises) {
    const minReps = item.templateExercise?.minReps ?? null;
    const maxReps = item.templateExercise?.maxReps ?? null;
    const targetReps = minReps && maxReps ? Math.round((minReps + maxReps) / 2) : maxReps ?? minReps ?? null;
    const best = bestByExercise.get(item.exerciseId);

    if (!best || !targetReps) {
      suggestions[item.id] = {
        suggestedWeight: null,
        targetReps,
        sourceE1rm: best?.e1rm ?? null,
        sourceSet: best ? `${best.weight} × ${best.reps}` : null,
      };
      continue;
    }

    const estimatedWeight = best.e1rm / (1 + targetReps / 30);
    suggestions[item.id] = {
      suggestedWeight: roundToNearestHalf(estimatedWeight),
      targetReps,
      sourceE1rm: Number(best.e1rm.toFixed(1)),
      sourceSet: `${best.weight} × ${best.reps}`,
    };
  }

  return suggestions;
}

export async function getWorkoutLoggerData(params?: { programId?: string; templateId?: string; sessionId?: string }) {
  const userId = await requireUserId();

  const programs = await prisma.program.findMany({
    where: { userId, isArchived: false },
    orderBy: [{ isActive: "desc" }, { createdAt: "asc" }],
  });

  const selectedProgram =
    programs.find((program) => program.id === params?.programId) ?? programs.find((program) => program.isActive) ?? programs[0] ?? null;

  const templates = selectedProgram ? await ensureProgramTemplates(selectedProgram.id, userId) : [];
  const suggestedTemplate = selectedProgram ? await getSuggestedTemplate(selectedProgram.id, userId, templates) : null;
  const selectedTemplate =
    templates.find((template) => template.id === params?.templateId) ?? suggestedTemplate ?? templates[0] ?? null;

  const [exercises, setTypes, draftSessions] = await Promise.all([
    prisma.exercise.findMany({
      where: { isArchived: false, isActive: true, OR: [{ isSeed: true, userId: null }, { userId }] },
      orderBy: [{ isSeed: "desc" }, { name: "asc" }],
      include: {
        movementGroup: true,
        primaryMuscles: { include: { muscle: true }, orderBy: { muscle: { sortOrder: "asc" } } },
        secondaryMuscles: { include: { muscle: true }, orderBy: { muscle: { sortOrder: "asc" } } },
      },
    }),
    prisma.setType.findMany({ orderBy: { sortOrder: "asc" } }),
    prisma.workoutSession.findMany({
      where: { userId, status: "DRAFT" },
      orderBy: { updatedAt: "desc" },
      take: 5,
      include: { program: true, template: true },
    }),
  ]);

  const requestedSession = params?.sessionId ? await getSessionForUser(params.sessionId, userId) : null;
  const activeSession = requestedSession?.status === "DRAFT" || requestedSession?.status === "COMPLETED" ? requestedSession : null;
  const hasUnfinishedSession = draftSessions.length > 0;
  const weightSuggestions = await buildWeightSuggestionsForSession(activeSession, userId);

  return {
    programs,
    selectedProgram,
    templates,
    suggestedTemplate,
    selectedTemplate,
    exercises,
    setTypes,
    draftSessions,
    activeSession,
    hasUnfinishedSession,
    weightSuggestions,
  };
}

async function getSuggestedTemplate(
  programId: string,
  userId: string,
  templates: Array<{ id: string; name: string; sequenceIndex: number; weekday: number | null }>,
) {
  if (templates.length === 0) return null;
  const program = await prisma.program.findFirst({ where: { id: programId, userId } });
  if (!program) return templates[0] ?? null;

  if (program.rotationStyle === "WEEKDAY_BASED") {
    const day = new Date().getDay();
    return templates.find((template) => template.weekday === day) ?? templates[0] ?? null;
  }

  if (program.rotationStyle === "MANUAL") return templates[0] ?? null;

  const lastCompleted = await prisma.workoutSession.findFirst({
    where: { userId, programId, status: "COMPLETED", templateId: { not: null } },
    orderBy: { performedAt: "desc" },
    include: { template: true },
  });
  if (!lastCompleted?.template) return templates[0] ?? null;
  const nextIndex = (lastCompleted.template.sequenceIndex + 1) % templates.length;
  return templates.find((template) => template.sequenceIndex === nextIndex) ?? templates[0] ?? null;
}

async function getTemplateWithExercises(templateId: string, userId: string) {
  return prisma.workoutTemplate.findFirst({
    where: { id: templateId, userId, isArchived: false, program: { userId, isArchived: false } },
    include: {
      program: true,
      exercises: {
        orderBy: { sortOrder: "asc" },
        include: {
          exercise: true,
          defaultSetType: true,
          setPlans: { orderBy: { setNumber: "asc" }, include: { setType: true } },
        },
      },
    },
  });
}

async function getSessionForUser(sessionId: string, userId: string) {
  return prisma.workoutSession.findFirst({
    where: { id: sessionId, userId },
    include: {
      program: true,
      template: true,
      exercises: {
        orderBy: { sortOrder: "asc" },
        include: {
          templateExercise: true,
          exercise: {
            include: {
              movementGroup: true,
              primaryMuscles: { include: { muscle: true }, orderBy: { muscle: { sortOrder: "asc" } } },
              secondaryMuscles: { include: { muscle: true }, orderBy: { muscle: { sortOrder: "asc" } } },
            },
          },
          substitutedFromExercise: true,
          sets: { orderBy: { setNumber: "asc" }, include: { setType: true } },
        },
      },
    },
  });
}


export async function getWorkoutHistory(take = 30) {
  const userId = await requireUserId();
  return prisma.workoutSession.findMany({
    where: { userId },
    orderBy: [{ performedAt: "desc" }, { createdAt: "desc" }],
    take,
    include: {
      program: true,
      template: true,
      exercises: {
        include: {
          exercise: true,
          sets: true,
        },
      },
    },
  });
}

export async function deleteWorkoutSession(sessionId: string, _formData?: FormData) {
  const userId = await requireUserId();
  const session = await prisma.workoutSession.findFirst({ where: { id: sessionId, userId } });
  if (!session) redirect("/log/history");

  await prisma.workoutSession.delete({ where: { id: session.id } });
  revalidateWorkoutViews();
  redirect("/log/history");
}

export async function startWorkout(formData: FormData) {
  const userId = await requireUserId();
  const input = startWorkoutSchema.parse({ programId: formData.get("programId"), templateId: formData.get("templateId") });
  const template = await getTemplateWithExercises(input.templateId, userId);
  if (!template || template.programId !== input.programId) redirect("/log");

  const session = await prisma.$transaction(async (tx) => {
    const created = await tx.workoutSession.create({
      data: {
        userId,
        programId: template.programId,
        templateId: template.id,
        name: template.name,
        status: "DRAFT",
      },
    });

    for (const [index, item] of template.exercises.entries()) {
      const sessionExercise = await tx.workoutSessionExercise.create({
        data: {
          sessionId: created.id,
          exerciseId: item.exerciseId,
          templateExerciseId: item.id,
          sortOrder: index,
          isSubstitution: false,
        },
      });

      const plannedSetRows = item.setPlans.length > 0
        ? item.setPlans.slice(0, item.plannedSets)
        : Array.from({ length: item.plannedSets }, (_, setIndex) => ({ setNumber: setIndex + 1, setTypeId: item.defaultSetTypeId }));

      for (const plan of plannedSetRows) {
        await tx.workoutSet.create({
          data: {
            sessionExerciseId: sessionExercise.id,
            setNumber: plan.setNumber,
            setTypeId: plan.setTypeId,
            rir: item.rirTarget,
            isCompleted: false,
          },
        });
      }
    }

    return created;
  });

  revalidateWorkoutViews();
  redirect(`/log?sessionId=${session.id}`);
}

export async function autosaveWorkoutSet(
  setId: string,
  payload: { weight?: string; reps?: string; rir?: string; setTypeId?: string; isCompleted?: boolean },
) {
  const userId = await requireUserId();
  const existing = await prisma.workoutSet.findFirst({
    where: { id: setId, sessionExercise: { session: { userId, status: editableSessionStatusWhere() } } },
    include: { sessionExercise: true },
  });
  if (!existing) return { ok: false, error: "Set not found or session is not editable." };

  const input = workoutSetSchema.safeParse({
    weight: parseNullableNumberInput(payload.weight),
    reps: parseNullableNumberInput(payload.reps),
    rir: parseNullableNumberInput(payload.rir),
    setTypeId: payload.setTypeId,
    isCompleted: Boolean(payload.isCompleted),
  });
  if (!input.success) return { ok: false, error: "Invalid set values." };

  await prisma.workoutSet.update({
    where: { id: existing.id },
    data: {
      weight: input.data.weight,
      reps: input.data.reps,
      rir: input.data.rir,
      setTypeId: input.data.setTypeId,
      isCompleted: input.data.isCompleted,
    },
  });

  revalidateWorkoutViews();
  return { ok: true };
}

export async function updateWorkoutSet(setId: string, formData: FormData) {
  const userId = await requireUserId();
  const existing = await prisma.workoutSet.findFirst({
    where: { id: setId, sessionExercise: { session: { userId, status: editableSessionStatusWhere() } } },
    include: { sessionExercise: { include: { session: true } } },
  });
  if (!existing) redirect("/log");

  const input = workoutSetSchema.parse({
    weight: numberOrNull(formData.get("weight")),
    reps: numberOrNull(formData.get("reps")),
    rir: numberOrNull(formData.get("rir")),
    setTypeId: formData.get("setTypeId"),
    isCompleted: formData.get("isCompleted") === "on",
  });

  await prisma.workoutSet.update({
    where: { id: existing.id },
    data: {
      weight: input.weight,
      reps: input.reps,
      rir: input.rir,
      setTypeId: input.setTypeId,
      isCompleted: input.isCompleted,
    },
  });

  revalidateWorkoutViews();
  redirect(`/log?sessionId=${existing.sessionExercise.sessionId}`);
}

export async function addWorkoutSet(formData: FormData) {
  const userId = await requireUserId();
  const sessionExerciseId = String(formData.get("sessionExerciseId") ?? "");
  const existing = await prisma.workoutSessionExercise.findFirst({
    where: { id: sessionExerciseId, session: { userId, status: editableSessionStatusWhere() } },
    include: {
      session: true,
      sets: { orderBy: { setNumber: "desc" }, take: 1 },
      templateExercise: { include: { setPlans: { orderBy: { setNumber: "asc" } } } },
    },
  });
  if (!existing) redirect("/log");

  const fallbackSetType = await prisma.setType.findFirst({ orderBy: { sortOrder: "asc" } });
  const nextSetNumber = (existing.sets[0]?.setNumber ?? 0) + 1;
  const plannedSetTypeId = existing.templateExercise?.setPlans.find((plan) => plan.setNumber === nextSetNumber)?.setTypeId;
  const setTypeId = plannedSetTypeId ?? existing.templateExercise?.defaultSetTypeId ?? fallbackSetType?.id;
  if (!setTypeId) redirect(`/log?sessionId=${existing.sessionId}`);

  await prisma.workoutSet.create({
    data: {
      sessionExerciseId: existing.id,
      setNumber: nextSetNumber,
      setTypeId,
      isCompleted: false,
    },
  });

  revalidateWorkoutViews();
  redirect(`/log?sessionId=${existing.sessionId}`);
}

export async function removeWorkoutSet(formData: FormData) {
  const userId = await requireUserId();
  const setId = String(formData.get("setId") ?? "");
  const existing = await prisma.workoutSet.findFirst({
    where: { id: setId, sessionExercise: { session: { userId, status: editableSessionStatusWhere() } } },
    include: { sessionExercise: true },
  });
  if (!existing) redirect("/log");

  await prisma.workoutSet.delete({ where: { id: existing.id } });
  revalidateWorkoutViews();
  redirect(`/log?sessionId=${existing.sessionExercise.sessionId}`);
}

export async function updateSessionExercise(sessionExerciseId: string, formData: FormData) {
  const userId = await requireUserId();
  const existing = await prisma.workoutSessionExercise.findFirst({
    where: { id: sessionExerciseId, session: { userId, status: editableSessionStatusWhere() } },
    include: { session: true, exercise: true },
  });
  if (!existing) redirect("/log");

  const input = sessionExerciseSchema.parse({
    exerciseId: formData.get("exerciseId"),
    painFlag: formData.get("painFlag") === "on",
    painNote: formData.get("painNote") ?? "",
    notes: formData.get("notes") ?? "",
  });

  const exercise = await prisma.exercise.findFirst({
    where: { id: input.exerciseId, isArchived: false, isActive: true, OR: [{ isSeed: true, userId: null }, { userId }] },
  });
  if (!exercise) redirect(`/log?sessionId=${existing.sessionId}`);

  await prisma.workoutSessionExercise.update({
    where: { id: existing.id },
    data: {
      exerciseId: input.exerciseId,
      isSubstitution: input.exerciseId !== existing.exerciseId || existing.isSubstitution,
      substitutedFromExerciseId: input.exerciseId !== existing.exerciseId ? existing.exerciseId : existing.substitutedFromExerciseId,
      painFlag: input.painFlag,
      painNote: input.painNote || null,
      notes: input.notes || null,
    },
  });

  revalidateWorkoutViews();
  redirect(`/log?sessionId=${existing.sessionId}`);
}

export async function addSessionExercise(formData: FormData) {
  const userId = await requireUserId();
  const sessionId = String(formData.get("sessionId") ?? "");
  const exerciseId = String(formData.get("exerciseId") ?? "");
  const session = await prisma.workoutSession.findFirst({
    where: { id: sessionId, userId, status: editableSessionStatusWhere() },
    include: { exercises: { orderBy: { sortOrder: "desc" }, take: 1 } },
  });
  if (!session) redirect("/log");

  const exercise = await prisma.exercise.findFirst({
    where: { id: exerciseId, isArchived: false, isActive: true, OR: [{ isSeed: true, userId: null }, { userId }] },
  });
  if (!exercise) redirect(`/log?sessionId=${session.id}`);

  const normalSetType = await prisma.setType.findFirst({ where: { slug: "normal" } }) ?? await prisma.setType.findFirst({ orderBy: { sortOrder: "asc" } });
  if (!normalSetType) redirect(`/log?sessionId=${session.id}`);

  await prisma.$transaction(async (tx) => {
    const created = await tx.workoutSessionExercise.create({
      data: {
        sessionId: session.id,
        exerciseId,
        sortOrder: (session.exercises[0]?.sortOrder ?? -1) + 1,
        isSubstitution: false,
      },
    });
    await tx.workoutSet.create({
      data: {
        sessionExerciseId: created.id,
        setNumber: 1,
        setTypeId: normalSetType.id,
        isCompleted: false,
      },
    });
  });

  revalidateWorkoutViews();
  redirect(`/log?sessionId=${session.id}`);
}

export async function finishWorkout(sessionId: string, formData: FormData) {
  const userId = await requireUserId();
  const session = await prisma.workoutSession.findFirst({ where: { id: sessionId, userId, status: "DRAFT" } });
  if (!session) redirect("/log");
  const input = finishWorkoutSchema.parse({ notes: formData.get("notes") ?? "" });

  await prisma.workoutSession.update({
    where: { id: session.id },
    data: { status: "COMPLETED", completedAt: new Date(), notes: input.notes || null },
  });

  revalidateWorkoutViews();
  redirect(`/log?sessionId=${session.id}`);
}
